

#ifndef _ENCODER_H_
#define _ENCODER_H_

#include "stm32f10x.h"

void Left_Encoder_Init(void);
void Right_Encoder_Init(void);


int Read_Encoder(u8 TIMX);










#endif // _ENCODER_H_

