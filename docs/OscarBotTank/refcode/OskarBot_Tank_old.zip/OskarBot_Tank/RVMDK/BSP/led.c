#include "stm32f10x.h"
#include "led.h"
#include "delay.h"




/**
	*	@brief		���������������
	*	@param		none
	*	@retval		none
	*/
void Beep_Led_Init(void)
{
	GPIO_InitTypeDef					GPIO_InitStructure ;

	/*ʹ��GPIOA��GPIOB��AFIO��TIM1����ʱ��*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	/*��ʼ��PA.13�˿�ΪOut_PPģʽ*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	//BEEP_ON;
	
	LED_ON;
	
	delay_ms(90);
	
	//BEEP_OFF;
	
	LED_OFF;
	
	delay_ms(90);
}


void Sys_OK_Sound(void)
{
	BEEP_ON;
	
	LED_ON;
	
	delay_ms(90);
	
	BEEP_OFF;
	
	LED_OFF;
	
	delay_ms(90);
	
	BEEP_ON;
	
	LED_ON;
	
	delay_ms(90);
	
	BEEP_OFF;
	
	LED_OFF;
	
	delay_ms(90);
	
	BEEP_ON;
	
	LED_ON;
	
	delay_ms(90);
	
	BEEP_OFF;
	
	LED_OFF;
}
