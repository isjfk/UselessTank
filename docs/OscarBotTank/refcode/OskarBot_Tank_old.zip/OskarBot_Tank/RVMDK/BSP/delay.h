#ifndef __DELAY_H
#define __DELAY_H 			   

#include "sys.h"  



void delay(u16 t);
void delay_ns(u16 t);
void delay_us(u16 t);
void delay_ms(u16 t);



#endif





























